package teste;

public enum FormatoMesa{
    RETANGULAR,
    EM_L
}