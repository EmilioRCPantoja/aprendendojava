package teste;

public enum TipoCadeira {
    SEM_RODINHA,
    COM_RODINHA
}
